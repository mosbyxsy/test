ZIP download test
